import os
import re
from telethon import TelegramClient, functions
from telethon.sessions import StringSession
from dotenv import load_dotenv

load_dotenv()

API_ID = int(os.getenv('TG_API_ID', '0'))
API_HASH = os.getenv('TG_API_HASH', '')
SESSION = os.getenv('TG_SESSION', '')

if not API_ID or not API_HASH:
    raise RuntimeError('TG_API_ID и TG_API_HASH не настроены в .env')

client = TelegramClient(StringSession(SESSION), API_ID, API_HASH)

NFT_RE = re.compile(r'(?:https?://)?t\.me/nft/([A-Za-z0-9_-]+)', re.I)


def extract_slug(text: str):
    m = NFT_RE.search(text or '')
    return m.group(1) if m else None


async def get_gift_and_price(slug: str):
    result = await client(functions.payments.GetUniqueStarGiftRequest(slug=slug))
    gift = result.gift
    owner = getattr(gift, 'owner_id', None)

    amounts = getattr(gift, 'resell_amount', None) or []
    price = None
    for amount in amounts:
        if hasattr(amount, 'amount'):
            price = int(amount.amount)
            break

    return gift, owner, price


async def send_buy_offer(nft_url: str):
    slug = extract_slug(nft_url)
    if not slug:
        raise ValueError('Не удалось распознать ссылку t.me/nft/...')

    gift, owner, price = await get_gift_and_price(slug)
    if owner is None:
        raise ValueError('Telegram не вернул владельца этого подарка.')
    if price is None:
        raise ValueError('У подарка сейчас нет цены перепродажи в Stars.')

    entity = await client.get_entity(owner)
    await client.send_message(entity, f'.buy {nft_url} {price} stars')

    return {
        'slug': slug,
        'title': getattr(gift, 'title', 'NFT'),
        'num': getattr(gift, 'num', None),
        'price': price,
        'owner': entity,
    }


async def start_user_client():
    await client.connect()
    if not await client.is_user_authorized():
        raise RuntimeError(
            'TG_SESSION не авторизован. Сначала запусти login_user.py и создай сессию.'
        )
    me = await client.get_me()
    print(f'User account connected: @{me.username or "no_username"} (id={me.id})')
