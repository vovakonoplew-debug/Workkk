import asyncio
import os
from telethon import TelegramClient
from telethon.sessions import StringSession
from dotenv import load_dotenv

load_dotenv()
api_id = int(os.getenv('TG_API_ID', '0'))
api_hash = os.getenv('TG_API_HASH', '')

if not api_id or not api_hash:
    print('Сначала добавь TG_API_ID и TG_API_HASH в .env')
    raise SystemExit(1)

async def main():
    client = TelegramClient(StringSession(), api_id, api_hash)
    await client.start()
    session = client.session.save()
    print('\nTG_SESSION=')
    print(session)
    print('\nСкопируй всю строку TG_SESSION в .env на хостинге.')
    await client.disconnect()

asyncio.run(main())
